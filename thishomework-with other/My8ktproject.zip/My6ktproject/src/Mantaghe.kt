class Mantaghe(name:String):edare(name) {
    var darsad:Float= 0.1F
    override fun payment(darsad:Float) {
        var money:Int = 100000
        println("this month they will recieve : ${money*darsad}")
    }


}