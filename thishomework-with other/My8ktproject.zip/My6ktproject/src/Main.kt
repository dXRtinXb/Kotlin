import kotlin.random.Random

fun main() {
    var name = "Artin"
     var data  = school(name , 1  , 2)
    println(data.edareName)
    data.TodayClasses
    data.fireHim("alizadeh")
    data.HisGrade("alizadeh" , null)
    data.sendRequest("please say hi" , null)
    data.payment(darsad = 0.1f)


}