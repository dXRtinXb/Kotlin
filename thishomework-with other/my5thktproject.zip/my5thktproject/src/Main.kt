fun main() {
    var myday = school("Artin" , 1 , 4)
    myday.fireHim("ALzadeh")
    myday.HisGrade("Alizadeh" ,0 )
    myday.dayPassesBy()
    


}