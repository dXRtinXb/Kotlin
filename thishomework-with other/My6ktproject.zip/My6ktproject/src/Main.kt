import kotlin.random.Random

fun main() {
    var name = "Artin"
     var data  = school(name , 1  , 2)
    data.TodayClasses
    data.fireHim("alizadeh")
    data.HisGrade("alizadeh" , null)
    data.sendRequest("please say hi" , null)


}