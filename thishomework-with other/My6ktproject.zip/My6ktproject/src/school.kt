class school constructor(name:String,day:Int , classes:Int) : edare(name ) {
    var name: String? = null
    var TodayClasses: Int? = null

    init {
        this.name = name
        this.TodayClasses = classes
        println(" Good morning $name")
    }

    fun dayPassesBy() {
        TodayClasses.let {x->
            for (index in 1..x!!) {
                println("the $index class is started...")
                println("the $index class is finished.")
            }

        }

        println("the day is finished")
    }

    fun fireHim(name: String) {
        println("the name ->$name is fired out of class")
    }

    fun HisGrade(name: String, Grade: Int?) {
        var gradeStatus: String = ""
        gradeStatus = when (Grade) {
            null -> "absent"
            else -> "No problem"
        }
        println(gradeStatus)
    }
}

