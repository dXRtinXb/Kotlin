fun main() {
//    these numbers are completely random
    var dadPermonth = 1750000
    var momPermonth = 1250000

    var dadMoneyPeryear = ((dadPermonth * 0.9 )*12)
    var momMoneyPeryear = ((momPermonth * 0.9 )*12)

    println("Dads gain money per year is: " + dadMoneyPeryear + " Toman")
    println("moms gain money per year is: " + momMoneyPeryear + " Toman")



}