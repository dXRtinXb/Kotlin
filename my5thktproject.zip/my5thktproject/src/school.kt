class S constructor(string:String?) {
    var string: String? = null


    init {
        this.string = string
    }
}

