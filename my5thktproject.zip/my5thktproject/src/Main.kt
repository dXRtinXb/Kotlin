import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Scanner

fun main() {

//    val s = S("Artin")
//    val datae:E = s as E


    
var inp:Any = 10


if(inp is Int){
    println("its int")
}else{
    println("its not int")
}

}