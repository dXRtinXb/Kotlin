fun main() {
    for (index in 1..1000 step 2) {
        println(index)
    }
}